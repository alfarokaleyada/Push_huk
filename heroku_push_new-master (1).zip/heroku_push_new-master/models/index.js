module.exports = {
	Fruit: require('./Fruit'),
	Sweets: require('./Sweets')
};
